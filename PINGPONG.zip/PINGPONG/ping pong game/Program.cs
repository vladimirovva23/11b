﻿
int firstPlayerPadSize = 4;
var secondPlayerPadSize = 4;

int ballPositionX = 5;
int ballPositionY = 5;
bool ballDirectionUp = true;
bool ballDirectionRight = true;


int firstPlayerPosition = 0;
int secondPlayerPosition = 0;

int firstPlayerResult = 0;
int secondPlayerResult = 0;

Random randomGenerator = new Random();

 void RemoveScrollBars()
{
    Console.ForegroundColor = ConsoleColor.Yellow;
    Console.BufferHeight = Console.WindowHeight;
    Console.BufferWidth = Console.WindowWidth;
    
}


void DrawFirstPlayer()
{
    for (int y = firstPlayerPosition; y < firstPlayerPosition + firstPlayerPadSize; y++)
    {
        PrintAtPosition(0, y, '|');
        PrintAtPosition(1 , y , '|');   
    }
}

 void PrintAtPosition(int x, int y, char symbol)
{
    Console.SetCursorPosition(x, y);
    Console.Write(symbol);
}

void DrawSecondPlayer()
{
    for (int y = secondPlayerPosition; y < secondPlayerPosition + secondPlayerPadSize; y++)
    {
        PrintAtPosition(Console.WindowWidth - 1, y, '|');
        PrintAtPosition(Console.WindowWidth - 2 , y, '|');
    }
}

void SetInitialPositions()
{
    firstPlayerPosition = Console.WindowHeight /2 - firstPlayerPadSize /2;
    secondPlayerPosition = Console.WindowHeight / 2 - firstPlayerPadSize / 2;
   SetBallAtTheMiddleOfTheGameField();
}

void MoveFirstPlayerDown()
{
    if (firstPlayerPosition < Console.WindowHeight - firstPlayerPadSize)
    {
        firstPlayerPosition++; 
    }
}

void MoveFirstPlayerUp()
{
    if (firstPlayerPosition > 0)
    {
        firstPlayerPosition--;
    }
}

void MoveSecondPlayerDown()
{
    if (secondPlayerPosition < Console.WindowHeight - secondPlayerPadSize)
    {
        secondPlayerPosition++;
    }
}

void MoveSecondPlayerUp()
{
    if (secondPlayerPosition > 0)
    {
        secondPlayerPosition--;
    }
}



void PrintResult()
{
    Console.SetCursorPosition(Console.WindowWidth / 2 - 1, 0);
    Console.WriteLine($"{firstPlayerResult} - {secondPlayerResult}");
}

void DrawBall()
{
    PrintAtPosition(ballPositionX, ballPositionY, '@');
}

void SetBallAtTheMiddleOfTheGameField()
{
    ballPositionX = Console.WindowWidth / 2;
    ballPositionY = Console.WindowHeight / 2;
}

void MoveBall()
{
    if (ballPositionY == 0)
    {
        ballDirectionUp = false;
    }
    if (ballPositionY == Console.WindowHeight - 1)
    {
        ballDirectionUp = true;
    }

    if (ballPositionX == Console.WindowWidth )
    {
        SetBallAtTheMiddleOfTheGameField();  
        ballDirectionRight = false;
        ballDirectionUp = true;
        firstPlayerResult ++;
        Console.SetCursorPosition(Console.WindowWidth / 2, Console.WindowHeight / 2);
        Console.WriteLine("First player wins!");
        Console.ReadKey();
        //second player L
    }
    if (ballPositionX == 0)
    {
        SetBallAtTheMiddleOfTheGameField();
        ballDirectionRight = true;
        secondPlayerResult ++;
        Console.SetCursorPosition(Console.WindowWidth / 2, Console.WindowHeight / 2);
        Console.WriteLine("Second player wins!");
        Console.ReadKey();
        //first player L
    }


    if (ballPositionX < 3)
    {
        if (ballPositionY >= firstPlayerPosition && ballPositionY < firstPlayerPosition + firstPlayerPadSize)
        {
            ballDirectionRight = true;
        }
    }

    if (ballPositionX >= Console.WindowWidth - 4)
    {
        if (ballPositionY >= secondPlayerPosition && ballPositionY < secondPlayerPosition + secondPlayerPadSize)
        {
            ballDirectionRight = false;
        }
    }


    if (ballDirectionUp)
    {
        ballPositionY--;
    }
    else
    {
        ballPositionY++;
    }


    if (ballDirectionRight)
    {
        ballPositionX++;
    }
    else
    {
        ballPositionX--;
    }


}

void SecondPlayerAIMove()
{
    int randomNumber = randomGenerator.Next(1 , 101);

    if (randomNumber < 70)
    {
        if (ballDirectionUp == true)
        {
            MoveSecondPlayerUp();
        }

        else
        {
            MoveSecondPlayerDown();
        }
    }
}

RemoveScrollBars();
SetInitialPositions();

while (true)
{
    if (Console.KeyAvailable)
    {
        ConsoleKeyInfo keyInfo = Console.ReadKey();
        if (keyInfo.Key == ConsoleKey.UpArrow)
        {
            MoveFirstPlayerUp();
        }

        if (keyInfo.Key == ConsoleKey.DownArrow)
        {
            MoveFirstPlayerDown();
        }
    }

    SecondPlayerAIMove();

    MoveBall();

    Console.Clear();
    DrawFirstPlayer();
    DrawSecondPlayer();
    DrawBall();
    PrintResult();

    Thread.Sleep(30);
}



